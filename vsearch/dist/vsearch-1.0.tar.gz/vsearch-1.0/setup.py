from setuptools import setup

setup(
    name='vsearch',
    version=1.0,
    description='functions and stuff for learning',
    author='Mr.Vodilovski',
    author_email='ksclsdmc',
    url='kncksdncds',
    py_modules=['functions'],


)
